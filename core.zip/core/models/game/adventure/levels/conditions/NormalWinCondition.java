package models.game.adventure.levels.conditions;

import models.game.WinCondition;

public class NormalWinCondition implements WinCondition {
    @Override
    public void isMet() {

    }
}
